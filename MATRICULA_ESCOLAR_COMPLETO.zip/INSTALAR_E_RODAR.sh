#!/bin/bash

# ============================================================================
# SCRIPT DE INSTALAÇÃO E EXECUÇÃO AUTOMÁTICA
# Sistema de Gerenciamento de Matrículas Escolares
# ============================================================================

set -e

echo "╔════════════════════════════════════════════════════════════════════════════╗"
echo "║                                                                            ║"
echo "║        SISTEMA DE GERENCIAMENTO DE MATRÍCULAS ESCOLARES                   ║"
echo "║        Script de Instalação e Execução Automática                         ║"
echo "║                                                                            ║"
echo "╚════════════════════════════════════════════════════════════════════════════╝"
echo ""

# ============================================================================
# VERIFICAR REQUISITOS
# ============================================================================

echo "📋 Verificando requisitos do sistema..."
echo ""

# Verificar Java
if ! command -v java &> /dev/null; then
    echo "❌ Java não está instalado!"
    echo "   Instale Java 17+ em: https://www.oracle.com/java/technologies/downloads/"
    exit 1
fi
JAVA_VERSION=$(java -version 2>&1 | grep -oP 'version "\K[^"]+')
echo "✅ Java $JAVA_VERSION encontrado"

# Verificar Maven
if ! command -v mvn &> /dev/null; then
    echo "❌ Maven não está instalado!"
    echo "   Instale Maven em: https://maven.apache.org/download.cgi"
    exit 1
fi
MVN_VERSION=$(mvn -version | head -n 1)
echo "✅ $MVN_VERSION encontrado"

# Verificar MySQL
if ! command -v mysql &> /dev/null; then
    echo "❌ MySQL não está instalado!"
    echo "   Instale MySQL 8.0+ em: https://dev.mysql.com/downloads/mysql/"
    exit 1
fi
echo "✅ MySQL encontrado"

# Verificar Redis
if ! command -v redis-cli &> /dev/null; then
    echo "❌ Redis não está instalado!"
    echo "   Instale Redis em: https://redis.io/download"
    exit 1
fi
echo "✅ Redis encontrado"

# Verificar Python
if ! command -v python3 &> /dev/null; then
    echo "❌ Python3 não está instalado!"
    echo "   Instale Python 3 em: https://www.python.org/downloads/"
    exit 1
fi
echo "✅ Python3 encontrado"

echo ""
echo "✅ Todos os requisitos foram encontrados!"
echo ""

# ============================================================================
# CRIAR BANCO DE DADOS
# ============================================================================

echo "🗄️  Criando banco de dados MySQL..."
echo ""

read -p "Digite a senha do usuário root do MySQL: " MYSQL_ROOT_PASSWORD

# Executar scripts SQL
mysql -u root -p"$MYSQL_ROOT_PASSWORD" < matricula-escolar-backend/scripts/01-schema.sql
mysql -u root -p"$MYSQL_ROOT_PASSWORD" < matricula-escolar-backend/scripts/02-create-user.sql

echo "✅ Banco de dados criado com sucesso!"
echo ""

# ============================================================================
# COMPILAR BACKEND
# ============================================================================

echo "🔨 Compilando Backend (Java Spring Boot)..."
echo ""

cd matricula-escolar-backend
mvn clean package -DskipTests

echo "✅ Backend compilado com sucesso!"
echo ""

cd ..

# ============================================================================
# INICIAR SERVIÇOS
# ============================================================================

echo "🚀 Iniciando serviços..."
echo ""

# Iniciar Redis em background
echo "Iniciando Redis..."
redis-server --daemonize yes
echo "✅ Redis iniciado"

# Iniciar Backend em background
echo "Iniciando Backend (Java Spring Boot)..."
cd matricula-escolar-backend
mvn spring-boot:run > /tmp/backend.log 2>&1 &
BACKEND_PID=$!
cd ..
echo "✅ Backend iniciado (PID: $BACKEND_PID)"

# Aguardar backend iniciar
echo "Aguardando backend iniciar (30 segundos)..."
sleep 30

# Verificar se backend está rodando
if curl -s http://localhost:8080/api/auth/login > /dev/null 2>&1; then
    echo "✅ Backend está respondendo"
else
    echo "⚠️  Backend pode estar demorando para iniciar..."
fi

# Iniciar Frontend em background
echo "Iniciando Frontend (HTTP Server)..."
cd matricula-escolar-frontend
python3 -m http.server 3000 > /tmp/frontend.log 2>&1 &
FRONTEND_PID=$!
cd ..
echo "✅ Frontend iniciado (PID: $FRONTEND_PID)"

echo ""
echo "╔════════════════════════════════════════════════════════════════════════════╗"
echo "║                                                                            ║"
echo "║                    ✅ SISTEMA INICIADO COM SUCESSO!                       ║"
echo "║                                                                            ║"
echo "║  Acesse no navegador: http://localhost:3000                               ║"
echo "║                                                                            ║"
echo "║  Credenciais de teste:                                                    ║"
echo "║  Email: admin@matricula.com                                               ║"
echo "║  Senha: admin123456                                                       ║"
echo "║                                                                            ║"
echo "║  Serviços rodando:                                                        ║"
echo "║  - Backend: http://localhost:8080/api                                     ║"
echo "║  - Frontend: http://localhost:3000                                        ║"
echo "║  - MySQL: localhost:3306                                                  ║"
echo "║  - Redis: localhost:6379                                                  ║"
echo "║                                                                            ║"
echo "║  Para parar os serviços, execute:                                         ║"
echo "║  kill $BACKEND_PID  (Backend)                                             ║"
echo "║  kill $FRONTEND_PID (Frontend)                                            ║"
echo "║  redis-cli shutdown (Redis)                                               ║"
echo "║                                                                            ║"
echo "╚════════════════════════════════════════════════════════════════════════════╝"
echo ""

# Manter script rodando
wait
