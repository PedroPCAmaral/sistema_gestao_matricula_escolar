# SISTEMA DE GERENCIAMENTO DE MATRÍCULAS ESCOLARES

## Trabalho Final - Laboratório de Banco de Dados

**Status:** ✅ Completo e Funcional  
**Versão:** 1.0.0  
**Data:** Novembro de 2025

---

## 📋 RESUMO EXECUTIVO

Sistema completo de gerenciamento de matrículas escolares desenvolvido com:
- **Backend:** Java Spring Boot 3.2.0
- **Frontend:** HTML5/CSS3/JavaScript Puro
- **Banco Relacional:** MySQL 8.0 com triggers, views, procedures e functions
- **Banco NoSQL:** Redis para fila de requisições
- **Autenticação:** JWT com Spring Security
- **Arquitetura:** 3 camadas bem definidas

---

## 🎯 REQUISITOS ATENDIDOS

✅ **Banco de Dados Relacional (MySQL)**
- 6 tabelas com relacionamentos
- 9 índices em colunas críticas
- 2+ Triggers (timestamp + auditoria)
- 2+ Views (alunos por turma + matrículas ativas)
- 2+ Procedures (registrar + cancelar matrícula)
- 3 Functions (gerar ID + calcular idade + validar CPF)
- Controle de acesso com usuário dedicado (sem root)

✅ **Banco de Dados NoSQL (Redis)**
- Fila de requisições de matrícula
- Fila de cancelamentos
- Status em tempo real

✅ **Backend (Java Spring Boot)**
- API REST completa
- Autenticação JWT
- Injeção de dependência
- CRUD para alunos, turmas e matrículas
- Validação completa

✅ **Frontend (HTML/CSS/JavaScript)**
- Interface responsiva
- Login com JWT
- CRUD completo
- Dashboard com estatísticas
- Modais e formulários

---

## 🚀 INÍCIO RÁPIDO

### 1. Extrair o ZIP
```bash
unzip matricula-escolar-completo.zip
cd matricula-escolar-backend
```

### 2. Criar Banco de Dados
```bash
mysql -u root -p < scripts/01-schema.sql
mysql -u root -p < scripts/02-create-user.sql
```

### 3. Compilar Backend
```bash
mvn clean package
```

### 4. Iniciar Serviços (4 terminais diferentes)

**Terminal 1 - Redis:**
```bash
redis-server
```

**Terminal 2 - Backend:**
```bash
cd matricula-escolar-backend
mvn spring-boot:run
```

**Terminal 3 - Frontend:**
```bash
cd matricula-escolar-frontend
python -m http.server 3000
```

**Terminal 4 - Navegador:**
```
http://localhost:3000
```

### 5. Fazer Login
- Email: `admin@matricula.com`
- Senha: `admin123456`

---

## 📁 ARQUIVOS INCLUÍDOS

- **README.md** - Este arquivo
- **ROTEIRO_APRESENTACAO.md** - Roteiro de 5 minutos
- **TRABALHO_ESCRITO.md** - Documento acadêmico completo
- **GUIA_INSTALACAO.docx** - Guia passo a passo em Word
- **LEIA-ME-PRIMEIRO.txt** - Instruções rápidas
- **INSTALAR_E_RODAR.sh** - Script executável
- **matricula-escolar-backend/** - Backend completo
- **matricula-escolar-frontend/** - Frontend completo

---

## 🔐 CREDENCIAIS DE TESTE

| Email | Senha | Grupo |
|-------|-------|-------|
| admin@matricula.com | admin123456 | ADMINISTRADOR |
| joao@matricula.com | prof123456 | PROFESSOR |
| maria@matricula.com | sec123456 | SECRETARIA |

---

## 📚 DOCUMENTAÇÃO

Todos os arquivos estão incluídos neste ZIP:

1. **README.md** - Visão geral
2. **ROTEIRO_APRESENTACAO.md** - Roteiro com timing
3. **TRABALHO_ESCRITO.md** - Artigo acadêmico
4. **GUIA_INSTALACAO.docx** - Guia em Word

---

## ✨ DESTAQUES

✅ Código limpo e profissional  
✅ Arquitetura em 3 camadas  
✅ Segurança com JWT e BCrypt  
✅ Performance com índices e Redis  
✅ Interface responsiva  
✅ Documentação completa  
✅ Pronto para produção  

---

**Boa sorte na apresentação! 🎓**
