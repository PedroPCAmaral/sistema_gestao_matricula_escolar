# ROTEIRO DE APRESENTAÇÃO - 5 MINUTOS

## ⏱️ TIMING

| Tempo | Seção | Duração |
|-------|-------|---------|
| 0:00-0:30 | Introdução | 30s |
| 0:30-1:00 | Visão Geral | 30s |
| 1:00-2:00 | MySQL | 60s |
| 2:00-2:30 | Redis | 30s |
| 2:30-3:30 | Backend | 60s |
| 3:30-4:15 | Frontend | 45s |
| 4:15-4:45 | Demonstração | 30s |
| 4:45-5:00 | Conclusão | 15s |

---

## 📊 SLIDE 1: INTRODUÇÃO (0:00-0:30)

**O que falar:**
"Bom dia/tarde. Meu nome é [seu nome] e vou apresentar o Sistema de Gerenciamento de Matrículas Escolares, desenvolvido como trabalho final de Laboratório de Banco de Dados. Este projeto demonstra domínio de conceitos avançados de SGBD, incluindo modelagem relacional, integração com NoSQL, autenticação segura e interface moderna."

---

## 🏗️ SLIDE 2: ARQUITETURA (0:30-1:00)

**O que falar:**
"O sistema foi desenvolvido com uma arquitetura em 3 camadas:

**Frontend:** HTML5/CSS3/JavaScript puro, interface responsiva com autenticação JWT.

**Backend:** Java Spring Boot 3.2.0 com API REST, injeção de dependência e validações completas.

**Dados:** MySQL 8.0 para dados relacionais e Redis para fila de requisições."

---

## 🗄️ SLIDE 3: MYSQL (1:00-2:00)

**O que falar:**
"O banco MySQL implementa todos os requisitos:

**Tabelas:** 6 tabelas com relacionamentos (usuarios, grupos_usuarios, turmas, alunos, matriculas, logs_auditoria).

**Índices:** 9 índices em colunas críticas para otimização.

**Triggers:** 2 triggers - um para timestamp automático e outro para auditoria.

**Views:** 2 views - alunos por turma e matrículas ativas.

**Procedures:** 2 procedures - registrar e cancelar matrícula.

**Functions:** 3 functions - gerar ID, calcular idade e validar CPF.

**Segurança:** Usuário dedicado sem privilégios root."

---

## 🔴 SLIDE 4: REDIS (2:00-2:30)

**O que falar:**
"Redis foi escolhido como NoSQL por 5 razões:

1. **Performance:** Operações em memória com latência mínima
2. **Simplicidade:** Estrutura de dados simples
3. **Fila nativa:** Suporte PUSH/POP com garantia FIFO
4. **Escalabilidade:** Múltiplos clientes simultâneos
5. **Integração:** Fácil com Spring Data Redis

Implementei 2 filas: matrículas e cancelamentos."

---

## ⚙️ SLIDE 5: BACKEND (2:30-3:30)

**O que falar:**
"Backend em Spring Boot com:

**Arquitetura:** Controllers → Services → Repositories → Models

**Autenticação:** JWT com Spring Security e BCrypt

**Injeção de Dependência:** Todas as classes usam @Autowired

**Validações:** Múltiplos níveis - entrada, negócio, banco

**Endpoints:** CRUD completo para alunos, turmas e matrículas

**Transações:** @Transactional para operações críticas"

---

## 🎨 SLIDE 6: FRONTEND (3:30-4:15)

**O que falar:**
"Frontend em HTML/CSS/JavaScript puro:

**Responsividade:** Mobile-first, funciona em todos os dispositivos

**Design:** Moderno com gradientes e animações

**Páginas:** Login, Dashboard, Alunos, Turmas, Matrículas

**Funcionalidades:** CRUD, busca, filtros, validação

**Segurança:** JWT, validação de entrada, CORS"

---

## 🎬 SLIDE 7: DEMONSTRAÇÃO (4:15-4:45)

**O que fazer:**
1. Fazer login
2. Criar um aluno
3. Criar uma turma
4. Registrar matrícula
5. Mostrar fila Redis

---

## 🎓 SLIDE 8: CONCLUSÃO (4:45-5:00)

**O que falar:**
"Em conclusão, este projeto demonstra aplicação prática de conceitos avançados de banco de dados: modelagem relacional, índices, triggers, views, procedures, functions, integração com NoSQL, autenticação segura, API REST e interface responsiva. O sistema é funcional, profissional e pronto para produção."

---

## ❓ POSSÍVEIS PERGUNTAS

**P: Por que Redis?**
R: Performance máxima com operações em memória, suporte nativo a filas e fácil integração.

**P: Como funciona autenticação?**
R: JWT com Spring Security. Usuário faz login, recebe token, inclui em todas as requisições.

**P: Como garantir integridade?**
R: Triggers para auditoria, procedures para lógica crítica, constraints de chave estrangeira, validações em múltiplos níveis.

**P: É escalável?**
R: Sim. Índices otimizados, cache Redis, arquitetura em camadas, separação de responsabilidades.

