# Backend - MatriculaEscolar

### Rodar
1. Ajuste `application.properties` com credenciais do MySQL (usuário backend_app criado pelo script SQL).
2. Rode o banco MySQL e MongoDB.
3. No diretório backend:
   ```bash
   mvn clean spring-boot:run
   ```
