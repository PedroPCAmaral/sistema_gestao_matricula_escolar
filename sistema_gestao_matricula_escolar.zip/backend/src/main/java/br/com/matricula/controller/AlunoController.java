package br.com.matricula.controller;

import br.com.matricula.model.Aluno;
import br.com.matricula.repository.AlunoRepository;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/alunos")
public class AlunoController {

    private final AlunoRepository repo;

    public AlunoController(AlunoRepository repo) { this.repo = repo; }

    @GetMapping
    public List<Aluno> listar() { return repo.findAll(); }

    @PostMapping
    public Aluno criar(@RequestBody Aluno a) {
        if (a.getIdAluno() == null) a.setIdAluno("ALU" + System.currentTimeMillis());
        return repo.save(a);
    }

    @PutMapping("/{id}")
    public Aluno atualizar(@PathVariable String id, @RequestBody Aluno a) {
        a.setIdAluno(id);
        return repo.save(a);
    }

    @DeleteMapping("/{id}")
    public void apagar(@PathVariable String id) { repo.deleteById(id); }
}
