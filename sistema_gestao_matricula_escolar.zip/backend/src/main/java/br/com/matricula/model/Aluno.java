package br.com.matricula.model;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import java.sql.Date;

@Entity
@Table(name = "alunos")
public class Aluno {
    @Id
    @Column(name = "id_aluno")
    private String idAluno;
    private String nome;
    @Column(name = "data_nascimento")
    private Date dataNascimento;
    private String email;

    public String getIdAluno() { return idAluno; }
    public void setIdAluno(String idAluno) { this.idAluno = idAluno; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public Date getDataNascimento() { return dataNascimento; }
    public void setDataNascimento(Date dataNascimento) { this.dataNascimento = dataNascimento; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
}
