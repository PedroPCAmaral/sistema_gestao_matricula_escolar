package br.com.matricula.model;

import jakarta.persistence.*;
import java.time.Instant;

@Entity
@Table(name = "usuarios")
public class Usuario {
    @Id
    @Column(name = "id_usuario")
    private String idUsuario;
    private String nome;
    private String login;
    @Column(name = "senha_hash")
    private String senhaHash;
    private String email;
    @ManyToOne
    @JoinColumn(name = "id_grupo")
    private GrupoUsuario grupo;
    @Column(name = "created_at")
    private Instant createdAt;

    public String getIdUsuario() { return idUsuario; }
    public void setIdUsuario(String idUsuario) { this.idUsuario = idUsuario; }
    public String getNome() { return nome; }
    public void setNome(String nome) { this.nome = nome; }
    public String getLogin() { return login; }
    public void setLogin(String login) { this.login = login; }
    public String getSenhaHash() { return senhaHash; }
    public void setSenhaHash(String senhaHash) { this.senhaHash = senhaHash; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public GrupoUsuario getGrupo() { return grupo; }
    public void setGrupo(GrupoUsuario grupo) { this.grupo = grupo; }
    public Instant getCreatedAt() { return createdAt; }
    public void setCreatedAt(Instant createdAt) { this.createdAt = createdAt; }
}
