package br.com.matricula.service;

import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Map;

@Service
public class MongoLogService {
    private final MongoTemplate mongoTemplate;

    public MongoLogService(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }

    public void log(String user, String action, Map<String, Object> payload) {
        var doc = Map.of(
                "user", user,
                "action", action,
                "payload", payload,
                "timestamp", Instant.now().toString()
        );
        mongoTemplate.save(doc, "auditoria_logs");
    }
}
