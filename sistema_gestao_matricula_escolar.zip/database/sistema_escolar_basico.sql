-- Script criado para o trabalho: criar schema, funções, triggers, views, procedures e usuários.
CREATE DATABASE IF NOT EXISTS matricula_escolar CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE matricula_escolar;

CREATE TABLE IF NOT EXISTS controle_ids (
    nome_seq VARCHAR(100) PRIMARY KEY,
    ultimo_valor INT NOT NULL
);

INSERT IGNORE INTO controle_ids (nome_seq, ultimo_valor) VALUES ('usuario_seq', 0), ('aluno_seq', 0);

DELIMITER //
CREATE FUNCTION fnc_gerar_id_usuario() RETURNS VARCHAR(20)
BEGIN
    UPDATE controle_ids SET ultimo_valor = ultimo_valor + 1 WHERE nome_seq='usuario_seq';
    RETURN CONCAT('USR', LPAD((SELECT ultimo_valor FROM controle_ids WHERE nome_seq='usuario_seq'), 6, '0'));
END;
//
DELIMITER ;

DELIMITER //
CREATE FUNCTION fnc_gerar_id_aluno() RETURNS VARCHAR(20)
BEGIN
    UPDATE controle_ids SET ultimo_valor = ultimo_valor + 1 WHERE nome_seq='aluno_seq';
    RETURN CONCAT('ALU', LPAD((SELECT ultimo_valor FROM controle_ids WHERE nome_seq='aluno_seq'), 6, '0'));
END;
//
DELIMITER ;

CREATE TABLE grupos_usuarios (
    id INT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL UNIQUE,
    descricao VARCHAR(255)
);

INSERT IGNORE INTO grupos_usuarios (id, nome, descricao) VALUES
(1, 'ADMIN', 'Acesso total ao sistema'),
(2, 'USER', 'Acesso limitado a consultas'),
(3, 'PROFESSOR', 'Acesso para operações acadêmicas');

CREATE TABLE usuarios (
    id_usuario VARCHAR(20) PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    login VARCHAR(50) NOT NULL UNIQUE,
    senha_hash VARCHAR(255) NOT NULL,
    email VARCHAR(100),
    id_grupo INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_grupo) REFERENCES grupos_usuarios(id)
);

CREATE TABLE turmas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    capacidade INT NOT NULL,
    vagas_ocupadas INT DEFAULT 0
);

CREATE TABLE alunos (
    id_aluno VARCHAR(20) PRIMARY KEY,
    nome VARCHAR(150) NOT NULL,
    data_nascimento DATE,
    email VARCHAR(120)
);

CREATE TABLE matriculas (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_aluno VARCHAR(20),
    id_turma INT,
    data_matricula TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_aluno) REFERENCES alunos(id_aluno),
    FOREIGN KEY (id_turma) REFERENCES turmas(id)
);

CREATE TABLE IF NOT EXISTS log_mudancas_alunos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_aluno VARCHAR(20),
    campo VARCHAR(100),
    valor_antigo TEXT,
    valor_novo TEXT,
    alterado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

DELIMITER //
CREATE TRIGGER trg_alunos_after_update
AFTER UPDATE ON alunos
FOR EACH ROW
BEGIN
    IF NEW.nome <> OLD.nome THEN
        INSERT INTO log_mudancas_alunos (id_aluno, campo, valor_antigo, valor_novo)
        VALUES (OLD.id_aluno, 'nome', OLD.nome, NEW.nome);
    END IF;
    IF NEW.email <> OLD.email THEN
        INSERT INTO log_mudancas_alunos (id_aluno, campo, valor_antigo, valor_novo)
        VALUES (OLD.id_aluno, 'email', OLD.email, NEW.email);
    END IF;
END;
//
DELIMITER ;

DELIMITER //
CREATE TRIGGER trg_matriculas_before_insert
BEFORE INSERT ON matriculas
FOR EACH ROW
BEGIN
    DECLARE vagas_restantes INT;
    SELECT (capacidade - vagas_ocupadas) INTO vagas_restantes FROM turmas WHERE id = NEW.id_turma FOR UPDATE;
    IF vagas_restantes <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Sem vagas na turma';
    END IF;
END;
//
DELIMITER ;

CREATE VIEW vw_info_basica_alunos AS
SELECT a.id_aluno, a.nome, a.email, m.id_turma, t.nome as nome_turma
FROM alunos a
LEFT JOIN matriculas m ON a.id_aluno = m.id_aluno
LEFT JOIN turmas t ON m.id_turma = t.id;

CREATE VIEW vw_turmas_com_vagas AS
SELECT t.id, t.nome, t.capacidade, t.vagas_ocupadas, (t.capacidade - t.vagas_ocupadas) as vagas_restantes
FROM turmas t;

DELIMITER //
CREATE PROCEDURE sp_matricular_aluno(IN p_id_aluno VARCHAR(20), IN p_id_turma INT)
BEGIN
    DECLARE vagas INT;
    START TRANSACTION;
    SELECT (capacidade - vagas_ocupadas) INTO vagas FROM turmas WHERE id = p_id_turma FOR UPDATE;
    IF vagas <= 0 THEN
        SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Não há vagas';
    ELSE
        INSERT INTO matriculas (id_aluno, id_turma) VALUES (p_id_aluno, p_id_turma);
        UPDATE turmas SET vagas_ocupadas = vagas_ocupadas + 1 WHERE id = p_id_turma;
    END IF;
    COMMIT;
END;
//
DELIMITER ;

DELIMITER //
CREATE FUNCTION fnc_contar_alunos_turma(p_id_turma INT) RETURNS INT DETERMINISTIC
BEGIN
    DECLARE qtd INT;
    SELECT COUNT(*) INTO qtd FROM matriculas WHERE id_turma = p_id_turma;
    RETURN qtd;
END;
//
DELIMITER ;

CREATE USER IF NOT EXISTS 'admin_app'@'localhost' IDENTIFIED BY 'SenhaAdmin123!';
GRANT ALL PRIVILEGES ON matricula_escolar.* TO 'admin_app'@'localhost';

CREATE USER IF NOT EXISTS 'backend_app'@'localhost' IDENTIFIED BY 'SenhaBack123!';
GRANT SELECT, INSERT, UPDATE, DELETE, EXECUTE ON matricula_escolar.* TO 'backend_app'@'localhost';

CREATE USER IF NOT EXISTS 'relatorio_app'@'localhost' IDENTIFIED BY 'SenhaRelatorio!';
GRANT SELECT ON matricula_escolar.* TO 'relatorio_app'@'localhost';

FLUSH PRIVILEGES;
