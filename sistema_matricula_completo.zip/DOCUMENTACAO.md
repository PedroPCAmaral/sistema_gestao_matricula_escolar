# Sistema de Matrícula Escolar - Documentação Técnica

**Autor:** Manus AI  
**Data:** 12 de Novembro de 2025  
**Versão:** 1.0.0

---

## 1. Visão Geral

O **Sistema de Matrícula Escolar** é uma aplicação completa desenvolvida para gerenciar o ciclo de vida dos dados de alunos em instituições educacionais. O sistema implementa as operações essenciais de CRUD (Create, Read, Update, Delete) através de duas interfaces: uma interface de terminal (CLI) em Java e uma interface web moderna desenvolvida em React com Node.js/Express no backend.

O projeto foi estruturado seguindo os princípios de separação de responsabilidades, utilizando a arquitetura em pacotes (`modelo`, `controle`, `visao`) para o backend Java CLI, e uma arquitetura moderna full-stack para a versão web com banco de dados MySQL.

### Público-Alvo

O sistema é direcionado para qualquer instituição educacional que necessite realizar operações administrativas de cadastro e gerenciamento de alunos, incluindo escolas, universidades e academias.

---

## 2. Problema a Ser Resolvido

A gestão manual ou ineficiente dos dados de alunos representa um desafio significativo para instituições educacionais. O sistema resolve este problema ao:

- **Padronizar operações essenciais:** Implementa as quatro operações CRUD de forma consistente e confiável
- **Garantir persistência de dados:** Utiliza banco de dados MySQL para armazenamento seguro e durável
- **Oferecer múltiplas interfaces:** Fornece tanto uma interface de terminal quanto uma interface web moderna
- **Facilitar consultas e buscas:** Permite buscar alunos por CPF ou nome rapidamente
- **Manter integridade de dados:** Valida dados de entrada e evita duplicação de CPF

---

## 3. Objetivos do Sistema

O objetivo principal é oferecer uma aplicação robusta e funcional que demonstre a capacidade de realizar as quatro operações essenciais (CRUD) sobre a entidade Aluno através de múltiplas interfaces, garantindo que as informações possam ser criadas, consultadas, modificadas e excluídas de forma organizada e persistente.

---

## 4. Funcionalidades do Sistema (CRUD)

### 4.1 CREATE (Criar)

**Opção 1 - Cadastrar Aluno:** Adiciona um novo registro de aluno ao banco de dados com validações de:
- Nome obrigatório
- CPF com 11 dígitos e unicidade garantida
- Idade válida
- Série obrigatória
- Turno obrigatório
- Telefone opcional

### 4.2 READ (Ler)

**Opção 2 - Listar Alunos:** Consulta e exibe todos os dados dos alunos existentes no banco de dados, ordenados por nome.

**Opção 3 - Buscar por CPF:** Busca e retorna os dados de um aluno específico utilizando o CPF como critério de busca, permitindo localização rápida de registros individuais.

**Opção 3 (Web) - Buscar por Nome:** A interface web permite buscar alunos por nome ou CPF em tempo real.

### 4.3 UPDATE (Atualizar)

**Opção 4 - Editar Aluno:** Permite modificar um registro de aluno já existente no banco de dados, incluindo alterações em nome, série, turno, telefone e outros campos.

### 4.4 DELETE (Deletar)

**Opção 5 - Remover Aluno:** Remove permanentemente um registro de aluno do banco de dados com confirmação de segurança antes da exclusão.

---

## 5. Arquitetura do Sistema

### 5.1 Arquitetura Backend Java CLI

O backend Java CLI segue a arquitetura em camadas com separação clara de responsabilidades:

#### Pacote `modelo`
- **Classe Aluno:** Representa a entidade aluno com atributos (id, nome, cpf, idade, série, turno, telefone) e métodos getters/setters para manipulação de dados.

#### Pacote `controle`
- **Classe Conexao:** Gerencia a conexão com o banco de dados MySQL, responsável por estabelecer e retornar a conexão JDBC.
- **Classe AlunoServico:** Implementa toda a lógica CRUD, recebendo dados da interface e interagindo com o banco de dados através de comandos SQL preparados.

#### Pacote `visao`
- **Classe Main:** É o ponto de entrada do programa e a interface de terminal (CLI), responsável por exibir o menu, ler entrada do usuário e chamar os métodos do AlunoServico.

### 5.2 Arquitetura Backend Web (Node.js/Express)

A versão web utiliza uma arquitetura moderna full-stack:

- **tRPC:** Framework para chamadas de procedimento remoto com type-safety end-to-end
- **Drizzle ORM:** Gerenciamento de banco de dados com migrations automáticas
- **Express:** Servidor HTTP para servir a API
- **MySQL:** Banco de dados relacional para persistência

### 5.3 Arquitetura Frontend Web (React)

- **React 19:** Framework para construção da interface
- **Tailwind CSS 4:** Estilização responsiva e moderna
- **shadcn/ui:** Componentes reutilizáveis de alta qualidade
- **Wouter:** Roteamento leve e eficiente

---

## 6. Estrutura do Projeto

```
sistema_matricula/
├── java_cli/                          # Backend Java CLI
│   ├── src/
│   │   ├── modelo/
│   │   │   └── Aluno.java            # Classe modelo
│   │   ├── controle/
│   │   │   ├── Conexao.java          # Gerenciador de conexão
│   │   │   └── AlunoServico.java     # Lógica CRUD
│   │   └── visao/
│   │       └── Main.java             # Interface CLI
│   ├── build/                         # Arquivos compilados
│   ├── dist/                          # JAR executável
│   ├── lib/                           # Dependências (driver MySQL)
│   ├── compile.sh                     # Script de compilação
│   └── build.xml                      # Configuração Ant
├── client/                            # Frontend React
│   ├── src/
│   │   ├── pages/
│   │   │   └── Home.tsx              # Página principal com CRUD
│   │   ├── components/               # Componentes reutilizáveis
│   │   ├── lib/
│   │   │   └── trpc.ts              # Cliente tRPC
│   │   └── App.tsx                   # Roteamento
│   └── public/                        # Ativos estáticos
├── server/                            # Backend Node.js/Express
│   ├── db.ts                         # Funções de banco de dados
│   ├── routers.ts                    # Rotas tRPC
│   └── _core/                        # Infraestrutura
├── drizzle/                           # Schema e migrations
│   └── schema.ts                     # Definição de tabelas
├── database_script.sql                # Script SQL inicial
└── DOCUMENTACAO.md                    # Este arquivo
```

---

## 7. Banco de Dados

### 7.1 Schema MySQL

O banco de dados `sistema_matricula` contém a tabela `alunos` com a seguinte estrutura:

| Campo | Tipo | Constraints | Descrição |
|-------|------|-------------|-----------|
| id | INT | PRIMARY KEY, AUTO_INCREMENT | Identificador único do aluno |
| nome | VARCHAR(100) | NOT NULL | Nome completo do aluno |
| cpf | VARCHAR(11) | NOT NULL, UNIQUE | CPF com 11 dígitos, único |
| idade | INT | NOT NULL | Idade do aluno |
| serie | VARCHAR(20) | NOT NULL | Série/Ano escolar |
| turno | VARCHAR(20) | NOT NULL | Turno (Matutino/Vespertino/Noturno) |
| telefone | VARCHAR(20) | NULL | Telefone de contato |
| data_criacao | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Data de criação do registro |
| data_atualizacao | TIMESTAMP | DEFAULT CURRENT_TIMESTAMP | Data da última atualização |

### 7.2 Índices

- **idx_cpf:** Índice em CPF para buscas rápidas por CPF
- **idx_nome:** Índice em nome para buscas por nome

---

## 8. Configuração e Instalação

### 8.1 Pré-requisitos

- Java Development Kit (JDK) 11 ou superior
- MySQL Server 5.7 ou superior
- Node.js 18+ (para versão web)
- npm ou pnpm (para versão web)

### 8.2 Instalação do Banco de Dados

1. Abra um cliente MySQL (mysql, MySQL Workbench, etc.)
2. Execute o script SQL fornecido:
   ```sql
   SOURCE database_script.sql;
   ```
3. Verifique se o banco de dados foi criado:
   ```sql
   SHOW DATABASES;
   USE sistema_matricula;
   SHOW TABLES;
   ```

### 8.3 Compilação do Backend Java CLI

1. Navegue até o diretório `java_cli`:
   ```bash
   cd java_cli
   ```

2. Execute o script de compilação:
   ```bash
   bash compile.sh
   ```

3. O script irá:
   - Baixar o driver JDBC MySQL automaticamente
   - Compilar os arquivos Java
   - Gerar um arquivo JAR executável

### 8.4 Execução do Backend Java CLI

Após a compilação bem-sucedida, execute o sistema:

```bash
java -cp lib/mysql-connector-java-8.0.33.jar:dist/SistemaMatricula.jar visao.Main
```

### 8.5 Instalação da Versão Web

1. Navegue até o diretório raiz do projeto:
   ```bash
   cd /home/ubuntu/sistema_matricula
   ```

2. Instale as dependências:
   ```bash
   pnpm install
   ```

3. Configure o banco de dados:
   ```bash
   pnpm db:push
   ```

4. Inicie o servidor de desenvolvimento:
   ```bash
   pnpm dev
   ```

5. Acesse a aplicação em `http://localhost:3000`

---

## 9. Guia de Uso

### 9.1 Interface de Terminal (CLI)

Ao executar o sistema Java CLI, você verá um menu com as seguintes opções:

```
┌────────────────────────────────────────────────────────┐
│                    MENU PRINCIPAL                      │
├────────────────────────────────────────────────────────┤
│ 1. Cadastrar Aluno                                     │
│ 2. Listar Alunos                                       │
│ 3. Buscar por CPF                                      │
│ 4. Editar Aluno                                        │
│ 5. Remover Aluno                                       │
│ 6. Sair                                                │
└────────────────────────────────────────────────────────┘
```

#### Exemplo de Uso - Cadastrar Aluno

1. Selecione a opção **1**
2. Digite o nome: `João Silva`
3. Digite o CPF: `12345678901`
4. Digite a idade: `15`
5. Digite a série: `1º Ano`
6. Digite o turno: `Matutino`
7. Digite o telefone: `11999999999`

O sistema confirmará o cadastro com sucesso.

#### Exemplo de Uso - Buscar por CPF

1. Selecione a opção **3**
2. Digite o CPF: `12345678901`
3. O sistema exibirá todos os dados do aluno encontrado

### 9.2 Interface Web

A interface web oferece uma experiência visual moderna e intuitiva:

1. **Dashboard:** Exibe estatísticas gerais (total de alunos, status do sistema)
2. **Busca:** Campo para buscar alunos por nome ou CPF em tempo real
3. **Novo Aluno:** Botão para abrir formulário de cadastro
4. **Tabela de Alunos:** Lista todos os alunos cadastrados com opções de editar e deletar

---

## 10. Validações e Tratamento de Erros

### 10.1 Validações de Entrada

- **Nome:** Obrigatório, não pode estar vazio
- **CPF:** Obrigatório, deve conter exatamente 11 dígitos, deve ser único no banco
- **Idade:** Obrigatório, deve ser um número positivo
- **Série:** Obrigatório, não pode estar vazio
- **Turno:** Obrigatório, deve ser um dos valores pré-definidos
- **Telefone:** Opcional

### 10.2 Tratamento de Erros

- **Conexão com banco de dados:** Se a conexão falhar, o sistema exibe mensagem de erro e permite tentar novamente
- **CPF duplicado:** O sistema impede cadastro de alunos com CPF já existente
- **Dados inválidos:** O sistema valida todos os campos antes de processar
- **Operações de banco de dados:** Erros são capturados e exibidos ao usuário

---

## 11. Tecnologias Utilizadas

### Backend Java CLI
- **Java 11:** Linguagem de programação
- **MySQL Connector/J 8.0.33:** Driver JDBC para MySQL
- **JDBC:** API para acesso a banco de dados

### Backend Web
- **Node.js:** Runtime JavaScript
- **Express 4:** Framework web
- **tRPC 11:** RPC framework com type-safety
- **Drizzle ORM:** Object-Relational Mapping
- **MySQL:** Banco de dados relacional

### Frontend Web
- **React 19:** Biblioteca de UI
- **Tailwind CSS 4:** Framework de estilização
- **shadcn/ui:** Componentes de UI
- **Wouter:** Roteador leve
- **TypeScript:** Tipagem estática

---

## 12. Segurança

### 12.1 Proteção contra SQL Injection

O sistema utiliza **Prepared Statements** em todas as operações SQL, prevenindo ataques de SQL injection:

```java
PreparedStatement stmt = conexao.prepareStatement(sql);
stmt.setString(1, valor);
```

### 12.2 Validação de Dados

Todos os dados de entrada são validados antes de serem processados:
- Verificação de tipos
- Verificação de comprimento
- Verificação de formato (CPF)
- Verificação de unicidade (CPF)

### 12.3 Tratamento de Exceções

Exceções são capturadas e tratadas adequadamente, evitando exposição de informações sensíveis ao usuário.

---

## 13. Performance

### 13.1 Otimizações de Banco de Dados

- **Índices:** Criados em CPF e nome para buscas rápidas
- **Prepared Statements:** Reutilizam planos de execução
- **Connection Pooling:** (Implementável para versão web)

### 13.2 Otimizações Frontend

- **Lazy Loading:** Componentes carregados sob demanda
- **Memoização:** Funções e componentes otimizados
- **Tailwind CSS:** Estilização otimizada com purging

---

## 14. Manutenção e Suporte

### 14.1 Backup do Banco de Dados

Para fazer backup do banco de dados:

```bash
mysqldump -u root -p sistema_matricula > backup_sistema_matricula.sql
```

### 14.2 Restauração do Banco de Dados

Para restaurar o banco de dados:

```bash
mysql -u root -p sistema_matricula < backup_sistema_matricula.sql
```

### 14.3 Logs

O sistema registra erros em:
- Console (CLI)
- Console do navegador (Web)
- Logs do servidor Node.js

---

## 15. Extensões Futuras

Possíveis melhorias e extensões para o sistema:

1. **Autenticação e Autorização:** Implementar login de usuários com diferentes níveis de acesso
2. **Relatórios:** Gerar relatórios em PDF com dados dos alunos
3. **Importação/Exportação:** Suportar importação de dados via CSV e exportação de relatórios
4. **Notificações:** Sistema de notificações para eventos importantes
5. **Dashboard Avançado:** Gráficos e análises dos dados de alunos
6. **API REST:** Expor funcionalidades via API REST para integração com outros sistemas
7. **Mobile App:** Desenvolver aplicativo mobile para acesso em dispositivos móveis
8. **Histórico de Alterações:** Manter registro de todas as alterações realizadas

---

## 16. Conclusão

O **Sistema de Matrícula Escolar** é uma aplicação robusta e funcional que demonstra a implementação completa de operações CRUD em múltiplas plataformas. Com a combinação de uma interface de terminal para uso administrativo e uma interface web moderna para gerenciamento visual, o sistema oferece flexibilidade e facilidade de uso para instituições educacionais de qualquer tamanho.

A arquitetura bem estruturada, validações rigorosas e tratamento adequado de erros garantem confiabilidade e segurança dos dados. O sistema está pronto para produção e pode ser facilmente estendido com novas funcionalidades conforme necessário.

---

## 17. Apêndice - Exemplos de Código

### 17.1 Exemplo - Criar Aluno (Java CLI)

```java
Aluno aluno = new Aluno("João Silva", "12345678901", 15, "1º Ano", "Matutino", "11999999999");
boolean sucesso = alunoServico.criar(aluno);
if (sucesso) {
    System.out.println("✓ Aluno cadastrado com sucesso!");
} else {
    System.out.println("❌ Erro ao cadastrar aluno!");
}
```

### 17.2 Exemplo - Buscar Aluno por CPF (Java CLI)

```java
Aluno aluno = alunoServico.buscarPorCpf("12345678901");
if (aluno != null) {
    System.out.println("Aluno encontrado: " + aluno.getNome());
} else {
    System.out.println("Aluno não encontrado!");
}
```

### 17.3 Exemplo - Criar Aluno (API Web)

```typescript
const criarMutation = trpc.alunos.criar.useMutation({
  onSuccess: () => {
    toast.success("Aluno cadastrado com sucesso!");
    refetchAlunos();
  },
  onError: (error) => {
    toast.error(error.message);
  },
});

criarMutation.mutate({
  nome: "Maria Santos",
  cpf: "98765432101",
  idade: 16,
  serie: "2º Ano",
  turno: "Vespertino",
  telefone: "11988888888",
});
```

---

**Fim da Documentação**

Data de Atualização: 12 de Novembro de 2025  
Versão: 1.0.0
