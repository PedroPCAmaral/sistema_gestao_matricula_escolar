# Sistema de Matrícula Escolar

Um sistema completo de cadastro de alunos com interface de terminal (CLI) em Java e interface web moderna em React.

## 🚀 Quick Start

### Versão Web

```bash
# Instalar dependências
pnpm install

# Configurar banco de dados
pnpm db:push

# Iniciar servidor de desenvolvimento
pnpm dev
```

Acesse em `http://localhost:3000`

### Versão CLI (Java)

```bash
# Compilar
cd java_cli
bash compile.sh

# Executar
java -cp lib/mysql-connector-java-8.0.33.jar:dist/SistemaMatricula.jar visao.Main
```

## 📋 Funcionalidades

- ✅ Cadastrar alunos
- ✅ Listar todos os alunos
- ✅ Buscar aluno por CPF
- ✅ Editar dados do aluno
- ✅ Remover aluno
- ✅ Validação de CPF duplicado
- ✅ Interface web responsiva
- ✅ Interface CLI interativa

## 🗄️ Banco de Dados

Executar script SQL para criar banco de dados:

```bash
mysql -u root -p < database_script.sql
```

## 📁 Estrutura do Projeto

```
sistema_matricula/
├── java_cli/              # Backend Java CLI
├── client/                # Frontend React
├── server/                # Backend Node.js/Express
├── drizzle/               # Schema e migrations
├── database_script.sql    # Script SQL
└── DOCUMENTACAO.docx      # Documentação completa
```

## 📖 Documentação

Veja `DOCUMENTACAO.md` ou `DOCUMENTACAO.docx` para documentação técnica completa.

## 🛠️ Tecnologias

- **Backend CLI:** Java 11, MySQL JDBC
- **Backend Web:** Node.js, Express, tRPC, Drizzle ORM
- **Frontend:** React 19, Tailwind CSS, shadcn/ui
- **Database:** MySQL

## 📝 Licença

Projeto acadêmico - Sistema de Matrícula Escolar
