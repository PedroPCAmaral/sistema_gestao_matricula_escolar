import { useEffect, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Trash2, Edit2, Plus, Search } from "lucide-react";
import { toast } from "sonner";

interface Aluno {
  id: number;
  nome: string;
  cpf: string;
  idade: number;
  serie: string;
  turno: string;
  telefone: string | null;
}

export default function Home() {
  const [alunos, setAlunos] = useState<Aluno[]>([]);
  const [filtro, setFiltro] = useState("");
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [editandoId, setEditandoId] = useState<number | null>(null);
  const [formData, setFormData] = useState({
    nome: "",
    cpf: "",
    idade: "",
    serie: "",
    turno: "Matutino",
    telefone: "",
  });

  // Queries
  const { data: alunosData, refetch: refetchAlunos } = trpc.alunos.listar.useQuery();
  const { data: totalData } = trpc.alunos.contar.useQuery();

  // Mutations
  const criarMutation = trpc.alunos.criar.useMutation({
    onSuccess: () => {
      toast.success("Aluno cadastrado com sucesso!");
      refetchAlunos();
      resetForm();
      setIsDialogOpen(false);
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao cadastrar aluno");
    },
  });

  const atualizarMutation = trpc.alunos.atualizar.useMutation({
    onSuccess: () => {
      toast.success("Aluno atualizado com sucesso!");
      refetchAlunos();
      resetForm();
      setIsDialogOpen(false);
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao atualizar aluno");
    },
  });

  const deletarMutation = trpc.alunos.deletar.useMutation({
    onSuccess: () => {
      toast.success("Aluno removido com sucesso!");
      refetchAlunos();
    },
    onError: (error) => {
      toast.error(error.message || "Erro ao remover aluno");
    },
  });

  useEffect(() => {
    if (alunosData) {
      setAlunos(alunosData);
    }
  }, [alunosData]);

  const resetForm = () => {
    setFormData({
      nome: "",
      cpf: "",
      idade: "",
      serie: "",
      turno: "Matutino",
      telefone: "",
    });
    setEditandoId(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!formData.nome || !formData.cpf || !formData.idade || !formData.serie) {
      toast.error("Preencha todos os campos obrigatórios");
      return;
    }

    if (formData.cpf.length !== 11 || !/^\d+$/.test(formData.cpf)) {
      toast.error("CPF deve conter 11 dígitos");
      return;
    }

    if (editandoId) {
      atualizarMutation.mutate({
        id: editandoId,
        nome: formData.nome,
        cpf: formData.cpf,
        idade: parseInt(formData.idade),
        serie: formData.serie,
        turno: formData.turno,
        telefone: formData.telefone || undefined,
      });
    } else {
      criarMutation.mutate({
        nome: formData.nome,
        cpf: formData.cpf,
        idade: parseInt(formData.idade),
        serie: formData.serie,
        turno: formData.turno,
        telefone: formData.telefone || undefined,
      });
    }
  };

  const handleEdit = (aluno: Aluno) => {
    setFormData({
      nome: aluno.nome,
      cpf: aluno.cpf,
      idade: aluno.idade.toString(),
      serie: aluno.serie,
      turno: aluno.turno,
      telefone: aluno.telefone || "",
    });
    setEditandoId(aluno.id);
    setIsDialogOpen(true);
  };

  const handleDelete = (id: number) => {
    if (confirm("Tem certeza que deseja remover este aluno?")) {
      deletarMutation.mutate({ id });
    }
  };

  const alunosFiltrados = alunos.filter(
    (aluno) =>
      aluno.nome.toLowerCase().includes(filtro.toLowerCase()) ||
      aluno.cpf.includes(filtro)
  );

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4 md:p-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-800 mb-2">
            Sistema de Matrícula Escolar
          </h1>
          <p className="text-gray-600">Gerenciar cadastro de alunos</p>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
          <Card className="bg-white shadow-lg">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                Total de Alunos
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-blue-600">
                {totalData?.total || 0}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-lg">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                Alunos Cadastrados
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-bold text-green-600">
                {alunosFiltrados.length}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-white shadow-lg">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-gray-600">
                Status
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-sm font-semibold text-green-600">
                Sistema Operacional
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Controls */}
        <div className="bg-white rounded-lg shadow-lg p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex-1">
              <div className="relative">
                <Search className="absolute left-3 top-3 text-gray-400 w-5 h-5" />
                <Input
                  type="text"
                  placeholder="Buscar por nome ou CPF..."
                  value={filtro}
                  onChange={(e) => setFiltro(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>

            <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
              <DialogTrigger asChild>
                <Button
                  onClick={() => {
                    resetForm();
                    setIsDialogOpen(true);
                  }}
                  className="bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="w-4 h-4 mr-2" />
                  Novo Aluno
                </Button>
              </DialogTrigger>

              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>
                    {editandoId ? "Editar Aluno" : "Cadastrar Novo Aluno"}
                  </DialogTitle>
                </DialogHeader>

                <form onSubmit={handleSubmit} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Nome *
                    </label>
                    <Input
                      type="text"
                      value={formData.nome}
                      onChange={(e) =>
                        setFormData({ ...formData, nome: e.target.value })
                      }
                      placeholder="Nome completo"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      CPF *
                    </label>
                    <Input
                      type="text"
                      value={formData.cpf}
                      onChange={(e) =>
                        setFormData({
                          ...formData,
                          cpf: e.target.value.replace(/\D/g, "").slice(0, 11),
                        })
                      }
                      placeholder="11 dígitos"
                      maxLength={11}
                      required
                      disabled={!!editandoId}
                    />
                  </div>

                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Idade *
                      </label>
                      <Input
                        type="number"
                        value={formData.idade}
                        onChange={(e) =>
                          setFormData({ ...formData, idade: e.target.value })
                        }
                        placeholder="Idade"
                        min="1"
                        required
                      />
                    </div>

                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">
                        Série *
                      </label>
                      <Input
                        type="text"
                        value={formData.serie}
                        onChange={(e) =>
                          setFormData({ ...formData, serie: e.target.value })
                        }
                        placeholder="1º Ano"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Turno *
                    </label>
                    <Select
                      value={formData.turno}
                      onValueChange={(value) =>
                        setFormData({ ...formData, turno: value })
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="Matutino">Matutino</SelectItem>
                        <SelectItem value="Vespertino">Vespertino</SelectItem>
                        <SelectItem value="Noturno">Noturno</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Telefone
                    </label>
                    <Input
                      type="tel"
                      value={formData.telefone}
                      onChange={(e) =>
                        setFormData({ ...formData, telefone: e.target.value })
                      }
                      placeholder="(11) 99999-9999"
                    />
                  </div>

                  <div className="flex gap-2 pt-4">
                    <Button
                      type="submit"
                      className="flex-1 bg-blue-600 hover:bg-blue-700"
                      disabled={criarMutation.isPending || atualizarMutation.isPending}
                    >
                      {criarMutation.isPending || atualizarMutation.isPending
                        ? "Salvando..."
                        : "Salvar"}
                    </Button>
                    <Button
                      type="button"
                      variant="outline"
                      onClick={() => setIsDialogOpen(false)}
                    >
                      Cancelar
                    </Button>
                  </div>
                </form>
              </DialogContent>
            </Dialog>
          </div>
        </div>

        {/* Table */}
        <Card className="bg-white shadow-lg overflow-hidden">
          <CardHeader className="bg-gray-50 border-b">
            <CardTitle>Lista de Alunos</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {alunosFiltrados.length === 0 ? (
              <div className="p-8 text-center text-gray-500">
                <p className="text-lg">Nenhum aluno cadastrado</p>
                <p className="text-sm">Clique em "Novo Aluno" para começar</p>
              </div>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b">
                    <tr>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">
                        Nome
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">
                        CPF
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">
                        Idade
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">
                        Série
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">
                        Turno
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">
                        Telefone
                      </th>
                      <th className="px-6 py-3 text-left text-sm font-semibold text-gray-700">
                        Ações
                      </th>
                    </tr>
                  </thead>
                  <tbody>
                    {alunosFiltrados.map((aluno) => (
                      <tr
                        key={aluno.id}
                        className="border-b hover:bg-gray-50 transition-colors"
                      >
                        <td className="px-6 py-4 text-sm text-gray-900">
                          {aluno.nome}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">
                          {aluno.cpf}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">
                          {aluno.idade}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">
                          {aluno.serie}
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <span className="px-3 py-1 bg-blue-100 text-blue-800 rounded-full text-xs font-semibold">
                            {aluno.turno}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-600">
                          {aluno.telefone || "-"}
                        </td>
                        <td className="px-6 py-4 text-sm">
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleEdit(aluno)}
                              className="text-blue-600 hover:text-blue-700"
                            >
                              <Edit2 className="w-4 h-4" />
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => handleDelete(aluno.id)}
                              className="text-red-600 hover:text-red-700"
                              disabled={deletarMutation.isPending}
                            >
                              <Trash2 className="w-4 h-4" />
                            </Button>
                          </div>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
