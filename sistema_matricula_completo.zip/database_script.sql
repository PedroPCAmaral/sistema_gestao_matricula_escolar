-- Script SQL para criar o banco de dados e a tabela de alunos
-- Sistema de Matrícula Escolar

-- Criar banco de dados
CREATE DATABASE IF NOT EXISTS sistema_matricula;

-- Usar o banco de dados
USE sistema_matricula;

-- Criar tabela de alunos
CREATE TABLE IF NOT EXISTS alunos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    cpf VARCHAR(11) NOT NULL UNIQUE,
    idade INT NOT NULL,
    serie VARCHAR(20) NOT NULL,
    turno VARCHAR(20) NOT NULL,
    telefone VARCHAR(20),
    data_criacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    data_atualizacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Criar índices para melhor performance
CREATE INDEX idx_cpf ON alunos(cpf);
CREATE INDEX idx_nome ON alunos(nome);

-- Inserir dados de exemplo (opcional)
INSERT INTO alunos (nome, cpf, idade, serie, turno, telefone) VALUES
('João Silva', '12345678901', 15, '1º Ano', 'Matutino', '11999999999'),
('Maria Santos', '98765432101', 16, '2º Ano', 'Vespertino', '11988888888'),
('Pedro Oliveira', '55555555555', 14, '1º Ano', 'Noturno', '11977777777');
