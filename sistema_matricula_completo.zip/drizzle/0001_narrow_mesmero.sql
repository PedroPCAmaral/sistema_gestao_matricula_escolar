CREATE TABLE `alunos` (
	`id` int AUTO_INCREMENT NOT NULL,
	`nome` varchar(100) NOT NULL,
	`cpf` varchar(11) NOT NULL,
	`idade` int NOT NULL,
	`serie` varchar(20) NOT NULL,
	`turno` varchar(20) NOT NULL,
	`telefone` varchar(20),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `alunos_id` PRIMARY KEY(`id`),
	CONSTRAINT `alunos_cpf_unique` UNIQUE(`cpf`)
);
