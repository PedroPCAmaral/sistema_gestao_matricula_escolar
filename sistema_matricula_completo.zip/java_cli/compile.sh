#!/bin/bash

# Script de compilação e execução do Sistema de Matrícula Escolar

echo "╔════════════════════════════════════════════════════════╗"
echo "║   COMPILAÇÃO - SISTEMA DE MATRÍCULA ESCOLAR           ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""

# Criar diretórios de build
mkdir -p build
mkdir -p dist
mkdir -p lib

# Baixar driver JDBC MySQL (se não existir)
if [ ! -f "lib/mysql-connector-java-8.0.33.jar" ]; then
    echo "Baixando driver MySQL JDBC..."
    cd lib
    wget -q https://repo1.maven.org/maven2/mysql/mysql-connector-java/8.0.33/mysql-connector-java-8.0.33.jar
    cd ..
fi

# Compilar o projeto
echo "Compilando arquivos Java..."
javac -d build -cp lib/mysql-connector-java-8.0.33.jar src/modelo/*.java src/controle/*.java src/visao/*.java

if [ $? -eq 0 ]; then
    echo "✓ Compilação realizada com sucesso!"
else
    echo "❌ Erro durante a compilação!"
    exit 1
fi

# Criar arquivo JAR
echo "Criando arquivo JAR..."
cd build
jar cvfe ../dist/SistemaMatricula.jar visao.Main modelo/*.class controle/*.class visao/*.class > /dev/null 2>&1
cd ..

if [ $? -eq 0 ]; then
    echo "✓ Arquivo JAR criado com sucesso!"
    echo ""
    echo "════════════════════════════════════════════════════════"
    echo "Para executar o sistema, use:"
    echo "  java -cp lib/mysql-connector-java-8.0.33.jar:dist/SistemaMatricula.jar visao.Main"
    echo "════════════════════════════════════════════════════════"
else
    echo "❌ Erro ao criar arquivo JAR!"
    exit 1
fi
