package controle;

import modelo.Aluno;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Classe AlunoServico - Implementa a lógica CRUD para alunos
 * Responsabilidade: Receber dados da interface e interagir com o banco de dados
 */
public class AlunoServico {

    /**
     * CREATE - Criar um novo aluno no banco de dados
     * @param aluno - Objeto Aluno a ser inserido
     * @return boolean - true se inserido com sucesso, false caso contrário
     */
    public boolean criar(Aluno aluno) {
        String sql = "INSERT INTO alunos (nome, cpf, idade, serie, turno, telefone) VALUES (?, ?, ?, ?, ?, ?)";
        
        try (Connection conexao = Conexao.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            
            stmt.setString(1, aluno.getNome());
            stmt.setString(2, aluno.getCpf());
            stmt.setInt(3, aluno.getIdade());
            stmt.setString(4, aluno.getSerie());
            stmt.setString(5, aluno.getTurno());
            stmt.setString(6, aluno.getTelefone());
            
            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;
        } catch (SQLException e) {
            System.err.println("Erro ao criar aluno: " + e.getMessage());
            return false;
        }
    }

    /**
     * READ - Listar todos os alunos
     * @return List<Aluno> - Lista de todos os alunos
     */
    public List<Aluno> listar() {
        List<Aluno> alunos = new ArrayList<>();
        String sql = "SELECT * FROM alunos ORDER BY nome";
        
        try (Connection conexao = Conexao.obterConexao();
             Statement stmt = conexao.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Aluno aluno = new Aluno(
                    rs.getInt("id"),
                    rs.getString("nome"),
                    rs.getString("cpf"),
                    rs.getInt("idade"),
                    rs.getString("serie"),
                    rs.getString("turno"),
                    rs.getString("telefone")
                );
                alunos.add(aluno);
            }
        } catch (SQLException e) {
            System.err.println("Erro ao listar alunos: " + e.getMessage());
        }
        
        return alunos;
    }

    /**
     * READ - Buscar aluno por CPF
     * @param cpf - CPF do aluno a buscar
     * @return Aluno - Objeto Aluno encontrado ou null
     */
    public Aluno buscarPorCpf(String cpf) {
        String sql = "SELECT * FROM alunos WHERE cpf = ?";
        
        try (Connection conexao = Conexao.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            
            stmt.setString(1, cpf);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Aluno(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("cpf"),
                        rs.getInt("idade"),
                        rs.getString("serie"),
                        rs.getString("turno"),
                        rs.getString("telefone")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar aluno por CPF: " + e.getMessage());
        }
        
        return null;
    }

    /**
     * READ - Buscar aluno por ID
     * @param id - ID do aluno a buscar
     * @return Aluno - Objeto Aluno encontrado ou null
     */
    public Aluno buscarPorId(int id) {
        String sql = "SELECT * FROM alunos WHERE id = ?";
        
        try (Connection conexao = Conexao.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            try (ResultSet rs = stmt.executeQuery()) {
                if (rs.next()) {
                    return new Aluno(
                        rs.getInt("id"),
                        rs.getString("nome"),
                        rs.getString("cpf"),
                        rs.getInt("idade"),
                        rs.getString("serie"),
                        rs.getString("turno"),
                        rs.getString("telefone")
                    );
                }
            }
        } catch (SQLException e) {
            System.err.println("Erro ao buscar aluno por ID: " + e.getMessage());
        }
        
        return null;
    }

    /**
     * UPDATE - Atualizar dados de um aluno existente
     * @param aluno - Objeto Aluno com dados atualizados
     * @return boolean - true se atualizado com sucesso, false caso contrário
     */
    public boolean atualizar(Aluno aluno) {
        String sql = "UPDATE alunos SET nome = ?, cpf = ?, idade = ?, serie = ?, turno = ?, telefone = ? WHERE id = ?";
        
        try (Connection conexao = Conexao.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            
            stmt.setString(1, aluno.getNome());
            stmt.setString(2, aluno.getCpf());
            stmt.setInt(3, aluno.getIdade());
            stmt.setString(4, aluno.getSerie());
            stmt.setString(5, aluno.getTurno());
            stmt.setString(6, aluno.getTelefone());
            stmt.setInt(7, aluno.getId());
            
            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;
        } catch (SQLException e) {
            System.err.println("Erro ao atualizar aluno: " + e.getMessage());
            return false;
        }
    }

    /**
     * DELETE - Remover um aluno do banco de dados
     * @param id - ID do aluno a remover
     * @return boolean - true se removido com sucesso, false caso contrário
     */
    public boolean remover(int id) {
        String sql = "DELETE FROM alunos WHERE id = ?";
        
        try (Connection conexao = Conexao.obterConexao();
             PreparedStatement stmt = conexao.prepareStatement(sql)) {
            
            stmt.setInt(1, id);
            
            int linhasAfetadas = stmt.executeUpdate();
            return linhasAfetadas > 0;
        } catch (SQLException e) {
            System.err.println("Erro ao remover aluno: " + e.getMessage());
            return false;
        }
    }

    /**
     * Verificar se um CPF já existe no banco de dados
     * @param cpf - CPF a verificar
     * @return boolean - true se existe, false caso contrário
     */
    public boolean cpfExiste(String cpf) {
        return buscarPorCpf(cpf) != null;
    }

    /**
     * Contar total de alunos
     * @return int - Total de alunos no banco de dados
     */
    public int contarAlunos() {
        String sql = "SELECT COUNT(*) as total FROM alunos";
        
        try (Connection conexao = Conexao.obterConexao();
             Statement stmt = conexao.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            if (rs.next()) {
                return rs.getInt("total");
            }
        } catch (SQLException e) {
            System.err.println("Erro ao contar alunos: " + e.getMessage());
        }
        
        return 0;
    }
}
