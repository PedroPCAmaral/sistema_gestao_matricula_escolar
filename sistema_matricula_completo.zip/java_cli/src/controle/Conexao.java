package controle;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Classe Conexao - Gerencia a conexão com o banco de dados MySQL
 * Responsabilidade: Estabelecer e retornar a conexão com o banco de dados
 */
public class Conexao {
    // Configurações de conexão
    private static final String URL = "jdbc:mysql://localhost:3306/sistema_matricula";
    private static final String USUARIO = "root";
    private static final String SENHA = "root";
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";

    /**
     * Método para obter a conexão com o banco de dados
     * @return Connection - Conexão com o banco de dados
     * @throws SQLException - Exceção de SQL
     */
    public static Connection obterConexao() throws SQLException {
        try {
            // Carregar o driver JDBC
            Class.forName(DRIVER);
            // Retornar a conexão
            return DriverManager.getConnection(URL, USUARIO, SENHA);
        } catch (ClassNotFoundException e) {
            System.err.println("Driver JDBC não encontrado: " + e.getMessage());
            throw new SQLException("Erro ao carregar o driver JDBC", e);
        } catch (SQLException e) {
            System.err.println("Erro ao conectar ao banco de dados: " + e.getMessage());
            throw e;
        }
    }

    /**
     * Método para fechar a conexão
     * @param conexao - Conexão a ser fechada
     */
    public static void fecharConexao(Connection conexao) {
        if (conexao != null) {
            try {
                conexao.close();
            } catch (SQLException e) {
                System.err.println("Erro ao fechar a conexão: " + e.getMessage());
            }
        }
    }
}
