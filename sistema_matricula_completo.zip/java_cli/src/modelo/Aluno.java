package modelo;

/**
 * Classe Aluno - Representa um aluno no sistema de matrícula
 * Atributos: id, nome, cpf, idade, série, turno, telefone
 */
public class Aluno {
    private int id;
    private String nome;
    private String cpf;
    private int idade;
    private String serie;
    private String turno;
    private String telefone;

    // Construtores
    public Aluno() {
    }

    public Aluno(String nome, String cpf, int idade, String serie, String turno, String telefone) {
        this.nome = nome;
        this.cpf = cpf;
        this.idade = idade;
        this.serie = serie;
        this.turno = turno;
        this.telefone = telefone;
    }

    public Aluno(int id, String nome, String cpf, int idade, String serie, String turno, String telefone) {
        this.id = id;
        this.nome = nome;
        this.cpf = cpf;
        this.idade = idade;
        this.serie = serie;
        this.turno = turno;
        this.telefone = telefone;
    }

    // Getters e Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getSerie() {
        return serie;
    }

    public void setSerie(String serie) {
        this.serie = serie;
    }

    public String getTurno() {
        return turno;
    }

    public void setTurno(String turno) {
        this.turno = turno;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    // Método toString para exibição
    @Override
    public String toString() {
        return "Aluno{" +
                "id=" + id +
                ", nome='" + nome + '\'' +
                ", cpf='" + cpf + '\'' +
                ", idade=" + idade +
                ", serie='" + serie + '\'' +
                ", turno='" + turno + '\'' +
                ", telefone='" + telefone + '\'' +
                '}';
    }
}
