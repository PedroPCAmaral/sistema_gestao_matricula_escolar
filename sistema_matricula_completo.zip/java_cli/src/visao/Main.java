package visao;

import controle.AlunoServico;
import modelo.Aluno;
import java.util.List;
import java.util.Scanner;

/**
 * Classe Main - Interface de terminal (CLI) para o sistema de matrícula
 * Responsabilidade: Exibir menu, ler entrada do usuário e chamar métodos do AlunoServico
 */
public class Main {
    private static AlunoServico alunoServico = new AlunoServico();
    private static Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("╔════════════════════════════════════════════════════════╗");
        System.out.println("║   SISTEMA DE MATRÍCULA ESCOLAR - CADASTRO DE ALUNOS   ║");
        System.out.println("╚════════════════════════════════════════════════════════╝");
        System.out.println();

        int opcao;
        do {
            exibirMenu();
            System.out.print("Escolha uma opção: ");
            opcao = lerInteiro();
            System.out.println();

            switch (opcao) {
                case 1:
                    cadastrarAluno();
                    break;
                case 2:
                    listarAlunos();
                    break;
                case 3:
                    buscarPorCpf();
                    break;
                case 4:
                    editarAluno();
                    break;
                case 5:
                    removerAluno();
                    break;
                case 6:
                    System.out.println("Encerrando o sistema. Até logo!");
                    break;
                default:
                    System.out.println("❌ Opção inválida! Tente novamente.");
            }
            System.out.println();
        } while (opcao != 6);

        scanner.close();
    }

    /**
     * Exibir o menu principal
     */
    private static void exibirMenu() {
        System.out.println("┌────────────────────────────────────────────────────────┐");
        System.out.println("│                    MENU PRINCIPAL                      │");
        System.out.println("├────────────────────────────────────────────────────────┤");
        System.out.println("│ 1. Cadastrar Aluno                                     │");
        System.out.println("│ 2. Listar Alunos                                       │");
        System.out.println("│ 3. Buscar por CPF                                      │");
        System.out.println("│ 4. Editar Aluno                                        │");
        System.out.println("│ 5. Remover Aluno                                       │");
        System.out.println("│ 6. Sair                                                │");
        System.out.println("└────────────────────────────────────────────────────────┘");
    }

    /**
     * Opção 1: Cadastrar um novo aluno
     */
    private static void cadastrarAluno() {
        System.out.println("═══════════════════════════════════════════════════════");
        System.out.println("              CADASTRO DE NOVO ALUNO");
        System.out.println("═══════════════════════════════════════════════════════");

        System.out.print("Nome: ");
        String nome = scanner.nextLine().trim();

        System.out.print("CPF (11 dígitos): ");
        String cpf = scanner.nextLine().trim();

        // Validar CPF
        if (cpf.length() != 11 || !cpf.matches("\\d+")) {
            System.out.println("❌ CPF inválido! Deve conter 11 dígitos.");
            return;
        }

        // Verificar se CPF já existe
        if (alunoServico.cpfExiste(cpf)) {
            System.out.println("❌ Erro: CPF já cadastrado no sistema!");
            return;
        }

        System.out.print("Idade: ");
        int idade = lerInteiro();

        System.out.print("Série (ex: 1º Ano, 2º Ano): ");
        String serie = scanner.nextLine().trim();

        System.out.print("Turno (Matutino/Vespertino/Noturno): ");
        String turno = scanner.nextLine().trim();

        System.out.print("Telefone: ");
        String telefone = scanner.nextLine().trim();

        Aluno aluno = new Aluno(nome, cpf, idade, serie, turno, telefone);

        if (alunoServico.criar(aluno)) {
            System.out.println("✓ Aluno cadastrado com sucesso!");
        } else {
            System.out.println("❌ Erro ao cadastrar aluno!");
        }
    }

    /**
     * Opção 2: Listar todos os alunos
     */
    private static void listarAlunos() {
        System.out.println("═══════════════════════════════════════════════════════");
        System.out.println("              LISTA DE ALUNOS CADASTRADOS");
        System.out.println("═══════════════════════════════════════════════════════");

        List<Aluno> alunos = alunoServico.listar();

        if (alunos.isEmpty()) {
            System.out.println("ℹ Nenhum aluno cadastrado no sistema.");
            return;
        }

        System.out.printf("%-5s %-25s %-15s %-6s %-15s %-12s %-15s%n",
                "ID", "Nome", "CPF", "Idade", "Série", "Turno", "Telefone");
        System.out.println("─".repeat(100));

        for (Aluno aluno : alunos) {
            System.out.printf("%-5d %-25s %-15s %-6d %-15s %-12s %-15s%n",
                    aluno.getId(),
                    aluno.getNome(),
                    aluno.getCpf(),
                    aluno.getIdade(),
                    aluno.getSerie(),
                    aluno.getTurno(),
                    aluno.getTelefone() != null ? aluno.getTelefone() : "N/A");
        }

        System.out.println("─".repeat(100));
        System.out.printf("Total de alunos: %d%n", alunos.size());
    }

    /**
     * Opção 3: Buscar aluno por CPF
     */
    private static void buscarPorCpf() {
        System.out.println("═══════════════════════════════════════════════════════");
        System.out.println("              BUSCAR ALUNO POR CPF");
        System.out.println("═══════════════════════════════════════════════════════");

        System.out.print("Digite o CPF: ");
        String cpf = scanner.nextLine().trim();

        Aluno aluno = alunoServico.buscarPorCpf(cpf);

        if (aluno != null) {
            System.out.println("\n✓ Aluno encontrado:");
            System.out.println("─".repeat(50));
            System.out.println("ID:       " + aluno.getId());
            System.out.println("Nome:     " + aluno.getNome());
            System.out.println("CPF:      " + aluno.getCpf());
            System.out.println("Idade:    " + aluno.getIdade());
            System.out.println("Série:    " + aluno.getSerie());
            System.out.println("Turno:    " + aluno.getTurno());
            System.out.println("Telefone: " + (aluno.getTelefone() != null ? aluno.getTelefone() : "N/A"));
            System.out.println("─".repeat(50));
        } else {
            System.out.println("❌ Aluno não encontrado!");
        }
    }

    /**
     * Opção 4: Editar dados de um aluno
     */
    private static void editarAluno() {
        System.out.println("═══════════════════════════════════════════════════════");
        System.out.println("              EDITAR DADOS DO ALUNO");
        System.out.println("═══════════════════════════════════════════════════════");

        System.out.print("Digite o CPF do aluno a editar: ");
        String cpf = scanner.nextLine().trim();

        Aluno aluno = alunoServico.buscarPorCpf(cpf);

        if (aluno == null) {
            System.out.println("❌ Aluno não encontrado!");
            return;
        }

        System.out.println("\nDados atuais:");
        System.out.println("Nome: " + aluno.getNome());
        System.out.println("Série: " + aluno.getSerie());
        System.out.println("Turno: " + aluno.getTurno());
        System.out.println("Telefone: " + (aluno.getTelefone() != null ? aluno.getTelefone() : "N/A"));

        System.out.println("\nDigite os novos dados (deixe em branco para manter):");

        System.out.print("Novo nome: ");
        String novoNome = scanner.nextLine().trim();
        if (!novoNome.isEmpty()) {
            aluno.setNome(novoNome);
        }

        System.out.print("Nova série: ");
        String novaSerie = scanner.nextLine().trim();
        if (!novaSerie.isEmpty()) {
            aluno.setSerie(novaSerie);
        }

        System.out.print("Novo turno: ");
        String novoTurno = scanner.nextLine().trim();
        if (!novoTurno.isEmpty()) {
            aluno.setTurno(novoTurno);
        }

        System.out.print("Novo telefone: ");
        String novoTelefone = scanner.nextLine().trim();
        if (!novoTelefone.isEmpty()) {
            aluno.setTelefone(novoTelefone);
        }

        if (alunoServico.atualizar(aluno)) {
            System.out.println("✓ Aluno atualizado com sucesso!");
        } else {
            System.out.println("❌ Erro ao atualizar aluno!");
        }
    }

    /**
     * Opção 5: Remover um aluno
     */
    private static void removerAluno() {
        System.out.println("═══════════════════════════════════════════════════════");
        System.out.println("              REMOVER ALUNO");
        System.out.println("═══════════════════════════════════════════════════════");

        System.out.print("Digite o CPF do aluno a remover: ");
        String cpf = scanner.nextLine().trim();

        Aluno aluno = alunoServico.buscarPorCpf(cpf);

        if (aluno == null) {
            System.out.println("❌ Aluno não encontrado!");
            return;
        }

        System.out.println("\nDados do aluno a remover:");
        System.out.println("Nome: " + aluno.getNome());
        System.out.println("CPF: " + aluno.getCpf());

        System.out.print("\nDeseja realmente remover este aluno? (S/N): ");
        String confirmacao = scanner.nextLine().trim().toUpperCase();

        if (confirmacao.equals("S")) {
            if (alunoServico.remover(aluno.getId())) {
                System.out.println("✓ Aluno removido com sucesso!");
            } else {
                System.out.println("❌ Erro ao remover aluno!");
            }
        } else {
            System.out.println("Operação cancelada.");
        }
    }

    /**
     * Método auxiliar para ler um inteiro do scanner
     * @return int - Inteiro lido
     */
    private static int lerInteiro() {
        int valor = 0;
        try {
            valor = Integer.parseInt(scanner.nextLine().trim());
        } catch (NumberFormatException e) {
            System.out.println("❌ Entrada inválida! Digite um número.");
        }
        return valor;
    }
}
