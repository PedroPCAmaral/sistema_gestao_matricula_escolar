import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, alunos, InsertAluno, Aluno } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ==================== CRUD de Alunos ====================

/**
 * Criar um novo aluno
 */
export async function criarAluno(aluno: InsertAluno): Promise<Aluno | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot create aluno: database not available");
    return null;
  }

  try {
    const result = await db.insert(alunos).values(aluno);
    // Retornar o aluno criado
    return await buscarAlunoPorId(result[0].insertId);
  } catch (error) {
    console.error("[Database] Failed to create aluno:", error);
    return null;
  }
}

/**
 * Listar todos os alunos
 */
export async function listarAlunos(): Promise<Aluno[]> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot list alunos: database not available");
    return [];
  }

  try {
    return await db.select().from(alunos);
  } catch (error) {
    console.error("[Database] Failed to list alunos:", error);
    return [];
  }
}

/**
 * Buscar aluno por ID
 */
export async function buscarAlunoPorId(id: number): Promise<Aluno | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get aluno: database not available");
    return null;
  }

  try {
    const result = await db.select().from(alunos).where(eq(alunos.id, id)).limit(1);
    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[Database] Failed to get aluno:", error);
    return null;
  }
}

/**
 * Buscar aluno por CPF
 */
export async function buscarAlunoPorCpf(cpf: string): Promise<Aluno | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get aluno: database not available");
    return null;
  }

  try {
    const result = await db.select().from(alunos).where(eq(alunos.cpf, cpf)).limit(1);
    return result.length > 0 ? result[0] : null;
  } catch (error) {
    console.error("[Database] Failed to get aluno by CPF:", error);
    return null;
  }
}

/**
 * Atualizar um aluno
 */
export async function atualizarAluno(id: number, dados: Partial<InsertAluno>): Promise<Aluno | null> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update aluno: database not available");
    return null;
  }

  try {
    await db.update(alunos).set(dados).where(eq(alunos.id, id));
    return await buscarAlunoPorId(id);
  } catch (error) {
    console.error("[Database] Failed to update aluno:", error);
    return null;
  }
}

/**
 * Deletar um aluno
 */
export async function deletarAluno(id: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot delete aluno: database not available");
    return false;
  }

  try {
    await db.delete(alunos).where(eq(alunos.id, id));
    // Verificar se o aluno foi deletado
    const verificacao = await buscarAlunoPorId(id);
    return verificacao === null;
  } catch (error) {
    console.error("[Database] Failed to delete aluno:", error);
    return false;
  }
}

/**
 * Verificar se CPF já existe
 */
export async function cpfExiste(cpf: string, excludeId?: number): Promise<boolean> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot check cpf: database not available");
    return false;
  }

  try {
    let query = db.select().from(alunos).where(eq(alunos.cpf, cpf));
    if (excludeId) {
      // Usar raw query para excluir um ID específico
      const result = await db.select().from(alunos).where(eq(alunos.cpf, cpf));
      return result.some(a => a.id !== excludeId);
    }
    const result = await query;
    return result.length > 0;
  } catch (error) {
    console.error("[Database] Failed to check cpf:", error);
    return false;
  }
}

/**
 * Contar total de alunos
 */
export async function contarAlunos(): Promise<number> {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot count alunos: database not available");
    return 0;
  }

  try {
    const result = await db.select().from(alunos);
    return result.length;
  } catch (error) {
    console.error("[Database] Failed to count alunos:", error);
    return 0;
  }
}
