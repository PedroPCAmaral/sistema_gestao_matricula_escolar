import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { z } from "zod";
import {
  criarAluno,
  listarAlunos,
  buscarAlunoPorId,
  buscarAlunoPorCpf,
  atualizarAluno,
  deletarAluno,
  cpfExiste,
  contarAlunos,
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // ==================== CRUD de Alunos ====================
  alunos: router({
    /**
     * Listar todos os alunos
     */
    listar: publicProcedure.query(async () => {
      const alunos = await listarAlunos();
      return alunos;
    }),

    /**
     * Buscar aluno por ID
     */
    buscarPorId: publicProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        const aluno = await buscarAlunoPorId(input.id);
        return aluno;
      }),

    /**
     * Buscar aluno por CPF
     */
    buscarPorCpf: publicProcedure
      .input(z.object({ cpf: z.string() }))
      .query(async ({ input }) => {
        const aluno = await buscarAlunoPorCpf(input.cpf);
        return aluno;
      }),

    /**
     * Criar novo aluno
     */
    criar: publicProcedure
      .input(
        z.object({
          nome: z.string().min(1, "Nome é obrigatório"),
          cpf: z.string().regex(/^\d{11}$/, "CPF deve conter 11 dígitos"),
          idade: z.number().min(1, "Idade deve ser maior que 0"),
          serie: z.string().min(1, "Série é obrigatória"),
          turno: z.string().min(1, "Turno é obrigatório"),
          telefone: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        // Verificar se CPF já existe
        const jaExiste = await cpfExiste(input.cpf);
        if (jaExiste) {
          throw new Error("CPF já cadastrado no sistema");
        }

        const aluno = await criarAluno({
          nome: input.nome,
          cpf: input.cpf,
          idade: input.idade,
          serie: input.serie,
          turno: input.turno,
          telefone: input.telefone || null,
        });

        if (!aluno) {
          throw new Error("Erro ao criar aluno");
        }

        return aluno;
      }),

    /**
     * Atualizar aluno
     */
    atualizar: publicProcedure
      .input(
        z.object({
          id: z.number(),
          nome: z.string().optional(),
          cpf: z.string().optional(),
          idade: z.number().optional(),
          serie: z.string().optional(),
          turno: z.string().optional(),
          telefone: z.string().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...dados } = input;

        // Se CPF foi alterado, verificar se já existe
        if (dados.cpf) {
          const jaExiste = await cpfExiste(dados.cpf, id);
          if (jaExiste) {
            throw new Error("CPF já cadastrado no sistema");
          }
        }

        const aluno = await atualizarAluno(id, dados);

        if (!aluno) {
          throw new Error("Erro ao atualizar aluno");
        }

        return aluno;
      }),

    /**
     * Deletar aluno
     */
    deletar: publicProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const sucesso = await deletarAluno(input.id);

        if (!sucesso) {
          throw new Error("Erro ao deletar aluno");
        }

        return { sucesso: true };
      }),

    /**
     * Contar total de alunos
     */
    contar: publicProcedure.query(async () => {
      const total = await contarAlunos();
      return { total };
    }),
  }),
});

export type AppRouter = typeof appRouter;
