# Sistema de Matrícula Escolar - TODO

## Backend Java CLI (CRUD Terminal)
- [x] Criar classe Aluno (modelo) com atributos: id, nome, cpf, idade, série, turno, telefone
- [x] Criar classe Conexao (controle) para conectar ao banco de dados MySQL
- [x] Criar classe AlunoServico (controle) com lógica CRUD completa
- [x] Criar classe Main (visão) com interface de terminal (CLI) e menu interativo
- [x] Compilar e testar o sistema Java CLI

## Banco de Dados MySQL
- [x] Criar script SQL para criar tabela de alunos
- [x] Criar script SQL para criar banco de dados
- [ ] Testar conexão com o banco de dados

## Frontend Web
- [x] Criar interface web em HTML/CSS/JavaScript puro
- [x] Implementar funcionalidade de cadastro de alunos
- [x] Implementar funcionalidade de listagem de alunos
- [x] Implementar funcionalidade de busca por CPF
- [x] Implementar funcionalidade de edição de alunos
- [x] Implementar funcionalidade de exclusão de alunos
- [x] Integrar front-end com back-end (API)

## Backend API (Node.js/Express)
- [x] Criar rotas API para CRUD de alunos
- [x] Integrar com banco de dados MySQL
- [x] Testar endpoints da API

## Documentação
- [x] Gerar documento Word com especificação do projeto
- [x] Incluir diagrama de arquitetura
- [x] Incluir instruções de compilação e execução
- [x] Incluir exemplos de uso

## Entrega
- [x] Compilar código Java
- [x] Preparar arquivos para entrega
- [ ] Gerar arquivo ZIP com todos os arquivos
